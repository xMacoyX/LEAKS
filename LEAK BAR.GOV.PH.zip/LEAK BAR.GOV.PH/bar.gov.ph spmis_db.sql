-- Adminer 4.8.1 MySQL 10.5.23-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `spmis_db` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `spmis_db`;

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` (`id`, `name`, `createdAt`) VALUES
(1,	'Fixtures and Furnitures',	'2024-03-19 03:09:58'),
(2,	'Office Supplies',	'2024-03-19 03:10:06'),
(3,	'Electrical Supplies',	'2024-03-19 03:10:14'),
(4,	'Janitorial Supplies',	'2024-03-19 03:10:25'),
(5,	'Computer Supplies',	'2024-03-19 03:10:34'),
(6,	'Writing Supplies',	'2024-03-19 03:10:43'),
(7,	'Building',	'2024-03-19 03:10:53'),
(8,	'Office Equipment',	'2024-03-19 03:11:00'),
(9,	'Information and Communication technology Equipment',	'2024-03-19 03:11:14'),
(10,	'Agricultural and Forestry Equipment',	'2024-03-19 03:11:26'),
(11,	'Communications Equipment',	'2024-03-19 03:11:34'),
(12,	'Motor Vehicle',	'2024-03-19 03:11:40');

DROP TABLE IF EXISTS `iar_items`;
CREATE TABLE `iar_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `iar_items` (`id`, `report_id`, `inventory_id`, `quantity`) VALUES
(38,	29,	29,	4),
(39,	30,	29,	1),
(40,	31,	29,	1),
(41,	31,	28,	1),
(42,	32,	29,	0),
(43,	33,	28,	221),
(44,	33,	29,	22);

DROP TABLE IF EXISTS `ia_report`;
CREATE TABLE `ia_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier` varchar(255) NOT NULL,
  `req_office` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `rcenter_code` varchar(100) DEFAULT NULL,
  `po_no` varchar(50) NOT NULL,
  `po_date` date NOT NULL,
  `iar_no` varchar(50) NOT NULL,
  `iar_date` date NOT NULL,
  `dr_no` varchar(50) NOT NULL,
  `dr_date` date NOT NULL,
  `inspection_officer` varchar(50) NOT NULL,
  `date_inspected` date DEFAULT NULL,
  `is_inspected` tinyint(4) NOT NULL,
  `head_psu` int(11) NOT NULL,
  `end_user` longtext NOT NULL,
  `enduser_designation` varchar(100) NOT NULL,
  `date_received` date DEFAULT NULL,
  `received_status` varchar(20) DEFAULT NULL,
  `received_qty` int(11) DEFAULT NULL,
  `status` varchar(50) NOT NULL COMMENT 'accepted, inspected, pending',
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `ia_report` (`id`, `supplier`, `req_office`, `rcenter_code`, `po_no`, `po_date`, `iar_no`, `iar_date`, `dr_no`, `dr_date`, `inspection_officer`, `date_inspected`, `is_inspected`, `head_psu`, `end_user`, `enduser_designation`, `date_received`, `received_status`, `received_qty`, `status`, `createdAt`) VALUES
(29,	'cbbcbcb',	'[\"OD\",\"OAD\",\"KMISD\"]',	'34543',	'4535-63-46',	'0536-04-23',	'4634-56',	'0346-06-24',	'6758-58',	'0347-06-05',	'1',	NULL,	1,	27,	'[\"25\",\"9\"]',	'[\"srfg dsgg\",\"sdgsdgg\"]',	NULL,	'',	0,	'',	'2024-05-11 02:52:45'),
(30,	'fdafsdaf',	'[\"OADP\",\"RCD\"]',	'34534',	'2453-45-346',	'0000-00-00',	'4564-57-7',	'2024-05-15',	'5656-88',	'2024-05-15',	'1',	NULL,	1,	24,	'[\"24\",\"15\",\"6\"]',	'[\"fdsfdaf\",\"sggdh\",\"zfzxvzxv\"]',	NULL,	NULL,	0,	'',	'2024-05-15 06:41:44'),
(31,	'fgvdfgdfg',	'[\"OADP\",\"RPDD\",\"ACEF\"]',	'34534',	'2323-5',	'2024-05-16',	'5645-77',	'2024-05-16',	'7867-86-7',	'2024-05-16',	'1',	NULL,	1,	25,	'[\"25\",\"27\",\"21\",\"27\"]',	'[\"sdfsd\",\"sdffgs\",\"dfgdgb\",\"fgfh\"]',	NULL,	'',	0,	'',	'2024-05-16 00:05:17'),
(32,	'chbdcfhdfgh',	'[\"OADP\",\"RPDD\"]',	'32553',	'2323-5',	'2024-05-16',	'4546-35-6',	'2024-05-16',	'7675-68',	'2024-05-16',	'1',	NULL,	1,	24,	'[\"25\",\"26\",\"24\"]',	'[\"cghgh\",\"fhh\",\"lhjl\"]',	NULL,	'',	0,	'',	'2024-05-16 06:34:08'),
(33,	'czsdfdfg',	'[\"OADP\",\"RPDD\",\"BIOTECH\",\"KMISD\"]',	'23534',	'3423-42-3',	'2024-05-20',	'4534-53-45',	'2024-05-20',	'4575-67-568',	'2024-05-20',	'3',	NULL,	1,	22,	'[\"27\",\"22\",\"10\"]',	'[\"Sample 1\",\"Sample 2\",\"Sample 3\"]',	NULL,	'',	0,	'',	'2024-05-20 02:18:41');

DROP TABLE IF EXISTS `ics_items`;
CREATE TABLE `ics_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ics_id` int(11) NOT NULL,
  `inv_id` int(11) NOT NULL,
  `unitcost` int(50) NOT NULL,
  `totalcost` decimal(50,0) NOT NULL,
  `estimated_life` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ics_items` (`id`, `ics_id`, `inv_id`, `unitcost`, `totalcost`, `estimated_life`, `quantity`) VALUES
(4,	28,	4,	0,	0,	'1 year',	2),
(5,	29,	5,	0,	0,	'1 yr',	1),
(6,	28,	6,	2000,	0,	'1',	1),
(7,	29,	7,	100,	0,	'dfg',	1),
(8,	29,	9,	100,	0,	'3',	2),
(9,	28,	10,	2000,	0,	'1',	2),
(10,	28,	11,	2000,	0,	'1',	1),
(11,	28,	12,	2000,	0,	'1',	1),
(12,	29,	13,	100,	0,	'fd',	2),
(13,	29,	14,	100,	0,	'1',	1),
(14,	28,	15,	2000,	0,	'',	1),
(15,	29,	16,	100,	100,	'1',	1),
(16,	28,	17,	2000,	4000,	'2',	2),
(17,	18,	18,	100,	400,	'4',	4),
(18,	19,	28,	2000,	4000,	'2',	2),
(19,	20,	30,	2000,	4000,	'fgh',	2),
(20,	20,	29,	100,	300,	'',	3),
(21,	21,	30,	2000,	6000,	'3',	3),
(22,	22,	28,	2000,	4000,	'5 years',	2),
(23,	23,	28,	2000,	6000,	'3',	3);

DROP TABLE IF EXISTS `ics_slip`;
CREATE TABLE `ics_slip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fund_cluster` varchar(100) NOT NULL,
  `ics_no` varchar(100) NOT NULL,
  `end_user` longtext NOT NULL,
  `enduser_designation` varchar(100) NOT NULL,
  `issued_by` int(11) NOT NULL,
  `issuedby_position` varchar(100) NOT NULL,
  `issued_date` date DEFAULT NULL,
  `received_by` int(11) NOT NULL,
  `receivedby_position` varchar(100) NOT NULL,
  `received_date` date DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ics_slip` (`id`, `fund_cluster`, `ics_no`, `end_user`, `enduser_designation`, `issued_by`, `issuedby_position`, `issued_date`, `received_by`, `receivedby_position`, `received_date`, `createdAt`) VALUES
(4,	'ftkfccf',	'64-48-646',	'',	'',	111,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	25,	'sample',	NULL,	'2024-05-10 02:29:29'),
(5,	'gdg',	'34-53-45',	'',	'',	23,	'sample',	NULL,	27,	'gdxfgxdfg',	NULL,	'2024-05-13 01:45:08'),
(6,	'234',	'34-5',	'',	'',	24,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	26,	'bfgh',	NULL,	'2024-05-20 06:07:56'),
(7,	'gdrg',	'45-23-5',	'',	'',	24,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	24,	'fgf',	NULL,	'2024-05-20 06:10:02'),
(9,	'vbfg',	'34-54-5',	'',	'',	23,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	23,	'adfadf',	NULL,	'2024-05-20 06:20:29'),
(10,	'dfgdfggf',	'45-34-5',	'',	'',	24,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	24,	'dfgfdg',	NULL,	'2024-05-20 06:22:43'),
(11,	's2345',	'35',	'',	'',	23,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	22,	'fd',	NULL,	'2024-05-20 06:35:44'),
(12,	's2345',	'35',	'',	'',	18,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	9,	'fd',	NULL,	'2024-05-20 06:37:18'),
(13,	'234',	'67-45-6',	'',	'',	22,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	18,	'fghgh',	NULL,	'2024-05-20 06:38:04'),
(14,	'sdg',	'23-4',	'',	'',	23,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	24,	'fgsfg',	NULL,	'2024-05-20 07:12:00'),
(15,	'234',	'34-54-565',	'',	'',	23,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	16,	'4',	NULL,	'2024-05-20 07:17:30'),
(16,	'234',	'34-54-565',	'',	'',	23,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	23,	'4',	NULL,	'2024-05-20 07:22:06'),
(17,	'dfhdfgfbhgnfgn',	'12-43-522',	'',	'',	16,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	14,	'dfgfgf',	NULL,	'2024-05-20 08:45:09'),
(18,	'dfgcfdfg',	'34-66-565',	'',	'',	22,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	19,	'rtyedy',	NULL,	'2024-05-20 08:50:55'),
(19,	'dfgdh',	'34-55-346',	'',	'',	24,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	18,	'dfhdcfhd',	NULL,	'2024-05-21 00:05:21'),
(20,	'sfgjmnghbkmhb',	'23-45-534',	'',	'',	26,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	21,	'drtgdtgd',	NULL,	'2024-05-21 00:08:51'),
(21,	'sdfsdgsdg',	'34-53-434',	'[\"21\",\"17\"]',	'[\"fhfdhfgjh\",\"fghfdh\"]',	20,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	24,	'ertetertre',	NULL,	'2024-05-21 00:45:47'),
(22,	'sdgdfgcfh',	'34-66',	'[\"21\"]',	'[\"\"]',	25,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	25,	'fghgf',	NULL,	'2024-05-21 01:18:25'),
(23,	'zdfgxdzhbcxfhcfh',	'23-53-453',	'[\"21\",\"20\",\"16\",\"10\"]',	'[\"dfgdfghdfg\",\"dfgg\",\"sdfgsdg\",\"fggfgf\"]',	23,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	21,	'dfgdgh',	NULL,	'2024-05-21 03:09:16');

DROP TABLE IF EXISTS `inspection_officer`;
CREATE TABLE `inspection_officer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'active',
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `inspection_officer` (`id`, `userID`, `status`, `createdAt`) VALUES
(1,	112,	'active',	'2024-03-19 05:07:56'),
(2,	13,	'inactive',	'2024-03-19 05:08:00'),
(3,	63,	'active',	'2024-04-12 01:14:54');

DROP TABLE IF EXISTS `inventory`;
CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inventory_date` date NOT NULL,
  `inventory_type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


DROP TABLE IF EXISTS `inventory_item`;
CREATE TABLE `inventory_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `stock_no` varchar(100) NOT NULL,
  `article` varchar(100) NOT NULL,
  `descriptions` text NOT NULL,
  `unit_measure` varchar(50) NOT NULL,
  `unit_value` double NOT NULL,
  `balance_per_card` int(11) NOT NULL,
  `onhand_per_count` int(11) NOT NULL,
  `shortage_qty` int(11) NOT NULL,
  `shortage_value` int(11) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `is_consumable` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1. True\r\n0. False',
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `inventory_item` (`id`, `category`, `stock_no`, `article`, `descriptions`, `unit_measure`, `unit_value`, `balance_per_card`, `onhand_per_count`, `shortage_qty`, `shortage_value`, `remarks`, `is_consumable`, `createdAt`) VALUES
(28,	1,	'10404010-00-01-01',	'Sample 1',	'This is a Sample',	'piece',	2000,	205,	0,	0,	0,	'',	0,	'2024-05-10 00:40:38'),
(29,	1,	'10404010-00-01-02',	'sample 2',	'sample 2',	'pad',	100,	33,	0,	0,	0,	'',	0,	'2024-05-10 02:14:59'),
(30,	3,	'10404010-00-01-04',	'Nice one',	'Sample 3',	'box',	2000,	-4,	0,	0,	0,	'',	0,	'2024-05-21 00:07:31');

DROP TABLE IF EXISTS `pa_items`;
CREATE TABLE `pa_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inventory_id` int(11) NOT NULL,
  `pa_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date_acquired` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `pa_items` (`id`, `inventory_id`, `pa_id`, `quantity`, `date_acquired`) VALUES
(8,	29,	5,	4,	'2024-05-10'),
(9,	28,	5,	2,	'2024-05-10'),
(10,	29,	6,	2,	'2024-05-10');

DROP TABLE IF EXISTS `pa_receipt`;
CREATE TABLE `pa_receipt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fund_cluster` varchar(1000) DEFAULT NULL,
  `par_no` varchar(50) NOT NULL,
  `issued_by` int(11) NOT NULL,
  `issued_position` varchar(100) NOT NULL,
  `issued_date` date DEFAULT NULL,
  `received_by` int(11) NOT NULL,
  `received_position` varchar(100) NOT NULL,
  `received_date` date DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `pa_receipt` (`id`, `fund_cluster`, `par_no`, `issued_by`, `issued_position`, `issued_date`, `received_by`, `received_position`, `received_date`, `createdAt`) VALUES
(5,	'ctcdj',	'4545-45-46',	111,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	24,	'sample',	NULL,	'2024-05-10 02:22:18'),
(6,	'sdfsf',	'2314',	23,	'HEAD, SUPPLY AND PROPERTY UNIT',	NULL,	24,	'fsfsdf',	NULL,	'2024-05-13 01:14:13');

DROP TABLE IF EXISTS `rai_slip`;
CREATE TABLE `rai_slip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `fund_cluster` varchar(50) NOT NULL,
  `division` int(11) DEFAULT NULL,
  `office` int(11) DEFAULT NULL,
  `res_code` varchar(50) DEFAULT NULL,
  `ris_no` varchar(50) DEFAULT NULL,
  `purpose` varchar(100) NOT NULL,
  `requested_by` int(11) DEFAULT NULL,
  `requested_designation` varchar(100) NOT NULL,
  `approved_by` int(11) NOT NULL,
  `approved_designation` varchar(100) NOT NULL,
  `issued_by` int(11) NOT NULL,
  `issued_designation` varchar(100) NOT NULL,
  `received_by` int(11) NOT NULL,
  `received_designation` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `requested_date` date NOT NULL,
  `approved_date` date NOT NULL,
  `issued__date` date NOT NULL,
  `received_date` date NOT NULL,
  `quantity` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `rai_slip` (`id`, `userID`, `fund_cluster`, `division`, `office`, `res_code`, `ris_no`, `purpose`, `requested_by`, `requested_designation`, `approved_by`, `approved_designation`, `issued_by`, `issued_designation`, `received_by`, `received_designation`, `status`, `createdAt`, `requested_date`, `approved_date`, `issued__date`, `received_date`, `quantity`) VALUES
(62,	212,	'0000-0000-0003',	1,	1,	'0000-0000-0003',	'0000-0000-0003',	'fjvgvjgvjgv',	9,	'iygvbgybbyggy',	25,	'gibgbybgy',	24,	'gbybgy',	27,	'ybgyb',	'approved',	'2024-05-10 02:35:56',	'2024-05-10',	'2024-05-10',	'2024-05-10',	'2024-05-10',	0),
(63,	212,	'0000-0000-000123',	3,	3,	'0000-0000-000123',	'0000-0000-000123',	'fsdgvfdgftdchjgfjh',	10,	'tdryrtyry',	9,	'erteryery',	23,	'rtytyurty',	25,	'rtyrtyrty',	'approved',	'2024-05-13 00:54:17',	'2024-05-13',	'2024-05-13',	'2024-05-13',	'2024-05-13',	0);

DROP TABLE IF EXISTS `ris_items`;
CREATE TABLE `ris_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inv_id` int(11) NOT NULL,
  `rai_id` int(11) NOT NULL,
  `stock_available` varchar(10) NOT NULL,
  `quantity` int(50) NOT NULL,
  `quantity_issue` int(11) NOT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ris_items` (`id`, `inv_id`, `rai_id`, `stock_available`, `quantity`, `quantity_issue`, `remarks`) VALUES
(80,	29,	62,	'yes',	2,	1,	'goods'),
(81,	29,	63,	'yes',	1,	2,	'arar'),
(82,	28,	63,	'yes',	1,	2,	'');

DROP TABLE IF EXISTS `spi_items`;
CREATE TABLE `spi_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `iar_id` int(11) NOT NULL,
  `ics_no` varchar(50) NOT NULL,
  `sep_no` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


DROP TABLE IF EXISTS `spi_report`;
CREATE TABLE `spi_report` (
  `id` int(11) NOT NULL,
  `fund_cluster` varchar(100) NOT NULL,
  `serial_no` varchar(50) NOT NULL,
  `spi_date` date NOT NULL,
  `posted_by` int(11) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


DROP TABLE IF EXISTS `transfer_items`;
CREATE TABLE `transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `inv_id` int(11) NOT NULL,
  `date_acquired` date DEFAULT NULL,
  `conditions` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `transfer_items` (`id`, `report_id`, `inv_id`, `date_acquired`, `conditions`) VALUES
(26,	27,	29,	'0000-00-00',	'goods'),
(27,	28,	28,	'2024-05-15',	''),
(28,	29,	28,	'2024-05-13',	''),
(29,	30,	29,	'0000-00-00',	'45');

DROP TABLE IF EXISTS `transfer_report`;
CREATE TABLE `transfer_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_type` varchar(50) NOT NULL,
  `end_user` int(11) DEFAULT NULL,
  `enduser_position` varchar(255) DEFAULT NULL,
  `from_accountable` varchar(255) NOT NULL,
  `to_accountable` varchar(255) NOT NULL,
  `itr_no` varchar(50) NOT NULL,
  `itr_date` date NOT NULL,
  `transfer_type` varchar(20) NOT NULL,
  `other_transfer_type` varchar(50) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `approved_by` varchar(100) NOT NULL,
  `approvedby_designation` varchar(100) NOT NULL,
  `approved_date` date NOT NULL,
  `released_by` varchar(100) NOT NULL,
  `releasedby_designation` varchar(100) DEFAULT NULL,
  `released_date` date NOT NULL,
  `received_by` varchar(100) NOT NULL,
  `receivedby_designation` varchar(100) NOT NULL,
  `received_date` date NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `transfer_report` (`id`, `asset_type`, `end_user`, `enduser_position`, `from_accountable`, `to_accountable`, `itr_no`, `itr_date`, `transfer_type`, `other_transfer_type`, `reason`, `approved_by`, `approvedby_designation`, `approved_date`, `released_by`, `releasedby_designation`, `released_date`, `received_by`, `receivedby_designation`, `received_date`, `createdAt`) VALUES
(27,	'inventory',	NULL,	NULL,	'jcftctc',	'cdtjcdtcd',	'355455',	'2024-05-10',	'reassignment',	NULL,	'jgcvfg',	'111',	'HEAD, SUPPLY AND PROPERTY UNIT',	'2024-05-10',	'25',	' hb h',	'2024-05-10',	'71',	'b h bh',	'2024-05-10',	'2024-05-10 02:31:11'),
(28,	'property',	NULL,	NULL,	'fjgtvftf',	'tjcftcv',	'65856',	'2024-05-10',	'relocate',	NULL,	'kgvghvgh',	'111',	'HEAD, SUPPLY AND PROPERTY UNIT',	'2024-05-10',	'27',	'ykvv',	'2024-05-10',	'71',	'vk gvg',	'2024-05-10',	'2024-05-10 02:32:58'),
(29,	'property',	NULL,	NULL,	'23425',	'434646',	'463464',	'2024-05-13',	'relocate',	NULL,	'fdgdfgdfggd',	'8',	'aefsefsrfsrf',	'2024-05-13',	'26',	'sdfsfdsfsf',	'2024-05-13',	'64',	'zfszfsf',	'2024-05-13',	'2024-05-13 01:57:14'),
(30,	'inventory',	NULL,	NULL,	'dgfd',	'gdgfdfg',	'545665',	'2024-05-13',	'reassignment',	NULL,	'vbnvbnv',	'8',	'dazsdasdf',	'2024-05-13',	'26',	'asfdaff',	'2024-05-13',	'71',	'fhgfhgfh',	'2024-05-13',	'2024-05-13 02:05:47');

-- 2024-07-02 14:57:54
